This [[vault]] comes with few pre-installed (and very popular) plugins. I find them useful, but you might not and that is completely fine!
Google what other people are using, or have a look at the **Core Plugins** and the **Community Plugins**

To do that, go to Settings⚙️, the gear down there in the bottom left. Then you can browse **Core plugins**, the ones that come with Obsidian, or click on **Community Plugins**, the ones made by people who use Obsidian everyday.

>[!tip] If you think of an useful setting, you can bet someone already made a plugin!

If you see a plugin you like in the list, just **Install it**. It will be stored locally in your Obsidian folder in your computer, under `.obsidian`. 
>[!warning] Remember to enable the plugin after installation!
> Just go to `Settings > Community Plugins` and toggle on the one you need.

Once you are in **Community Plugins**, have a look at the ones I downloaded for you. You can also set hotkeys for easy access! (tip, try to type `Ctrl/Cmd + win + E` and see what happens!)

Here there is a list of the plugins in this vault, and their core features:
### Dataview

**Dataview** is a powerful plugin in [[Obsidian]] that allows you to query and display notes based on metadata, [[tags]], and content. If you don't know what `metadata` is yet, go read the note [[Obsidian]]!

1. Type three **backticks** to create a code block. 
2. After the opening backticks, type `dataview`.
3. Write the query.

For example, you want all the notes tagged with `#biology`

```
list from #biology 
```
Output:
```dataview
list from #biology 
```
Or, you want a table with these information: `title, tags, status` of all the notes that have the tag `#biology` AND the status is `ongoing`.

```
table title, tags, status 
from #biology  where status = "ongoing"
```

Output:
```dataview 
table title, tags, status 
from #biology 
where status = "ongoing"
```

See how powerful `metadata`is?

Check the [Dataview documentation](https://blacksmithgu.github.io/obsidian-dataview/) for more information!

### ReadItLater

Imagine this: you are browsing on your favorite topic, let's say  #learning, and suddenly you bump into a very interesting article about #dogs and how human perception of dogs shapes the dogs' daily life. Now it's not the time to read it, but it would be nice to `ReadItLater`.

But where to store it so you will remember? 

1. Copy a link to the article, or resource. 
   It can be anything, including a `Youtube` video!
2. Use the Comman Palette (your best friend, remember?) `Ctrl/Cmd + P` to activate **Add to ReadItLater**
   *Tip: you can also set a hotkey!*
3. The plugin automatically creates a note in your designated folder (in this case called `ReadItLater Inbox`) with the link and `Metadata`
4. When you are ready to read it, you can open the note.
5. You can add `#tags` or `[[links]]`, or if you're done reading and you don't care about it anymore, just delete it.

Try it yourself. Here is the interesting paper about [Dogs](https://neurosciencenews.com/human-dog-behavior-psychology-28031/): open the link, copy the link and try to add it to the reading list. For this feature, you will need an Internet Connection.

You can also do it with local files! Try it with a `.pdf` or `.txt` file in your local computer.

### Looking for other Plugins?

These are the ones the workshop participants found useful:
- The [Importer](https://help.obsidian.md/Plugins/Importer): If you are a Notion user, this plugin helps you migrate to Obsidian
- [Daily Notes](https://help.obsidian.md/Plugins/Daily+notes): If you like Obsidian, but you also like Logseq journaling feature.



