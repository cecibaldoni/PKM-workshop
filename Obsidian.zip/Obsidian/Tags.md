Tags are keywords prefixed with the `#` symbol. They are lightweight and incredibly flexibly. ***They are different from [[Logseq]]  tags***, because they do not automatically create a new note!

Tags are clickable and allow you to view all notes in your vault that share the same tag.
Remember that tags are useful if they are **meaningful**. Avoid over-tagging and be consistent! For example, tags are case-sensitives, meaning that `#research` is different from `#Research`, and therefore treated as two different tags. 

>[!tip] 
To avoid problems, decide on a consistent capitalization style!
### Using Tags

 You can include tags directly within the body of your notes or in the note’s metadata section (`frontmatter`). 
 1. **In the Body**
	 Simply type `#` followed by the tag name in the note content:
	 
	 ``` Markdown
	 This is a note about #biology and #evolution. 
	 ```

 1. **In Metadata or Frontmatter**
	 Tags can also be included in a note's metadata section at the top of the file. Metadata is enclosed in triple dashes `---` and are usually used to define properties of the note:
	 ```markdown
	 ---
	 tags: [biology, evolution]
	 ---
	```

### Searching with Tags

You can use [[Obsidian]]’s search feature to find notes by tags:
```Markdown
tag:#biology
```
or:
``` Markdown
tag: #biology tag:#evolution
```
### Example Tags

**Topics**
`#biology` ; `#evolution` ; `#behavior` ; `#plasticity` ; `#conservation`

**Categories**
`#literature` ; `#methods`; `#pilot` ; `#writing` ; `#reviewing`

**Status**
`#todo` ; `#done`; `#ongoing` ; `#onhold` ; `#draft`

**Languages, Resources**
`#Rstudio` ; `#Python` ; `#C++` `#Arduino` ; `#git` ; `#ChatGPT`

**Personal**
`#home` ; `#gym` ; `#book` ; `#drawingideas`

**Moodlog**
`#stressed` ; `#focused` ; `#unfocused` ; `#content` ;  `#excited`