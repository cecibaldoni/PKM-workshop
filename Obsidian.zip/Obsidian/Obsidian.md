### Why Obsidian?

Obsidian has an **offline-first** design, meaning that all notes are stored locally as **Markdown files**. This makes Obsidian a secure and **privacy-focused** choice. The use of [[Markdown]] syntax ensure compatibility with other tolls, such as Quarto or Rstudio, and it's **future-proof**!
### How Are Notes Organised in Obsidian?

In Obsidian, notes are organised with a **folder-agnostic organisation**,  meaning it is not organised in hierarchical structures. You can still use folders for visual grouping in the File Explorer (the grey box on your upper left ⬅️), but Obsidian encourages a web-like structure where notes are connected with `[[links]]` and `#tags` .

Another handy feature is **aliases**—they allow a note to have alternative names that you can use to refer to it in links. This is particularly useful when a concept or note might have multiple synonymous terms, abbreviations, or slightly different phrasings.
For example, if you have a note about “Photosynthesis,” you could also link to it using “Plant Energy Conversion,” and it would point to the same place. Or if you are unsure of how strictly you stick to your title case, you might want to give it an alias with different options: e.g. `[Obsidian]` and the alias could be `[obsidian]`.

##### How Do Aliases Work:
When creating a note, it's a good practice to always define `Metadata` for that note. `Metadata` refers to the data of a note, and provides information that helps organize and retrieve the note. Metadata in Obsidian can be included in the note's **YAML's frontmatter** (on the top of the note, enclosed by triple dashes `---`), or within the note text.

Example:
``` yaml
---
title: Photosynthesis
tags: #plants, #biology 
aliases: [Plant Energy Conversion]
status: draft
---
```
Within the **aliases** metadata, if you make a link with ```[Plant Energy Conversion]``` and Obsidian will recognize the alias, linking it properly with the note titled `[Photosynthesis]`!

Check it yourself, make a new note with your own project and give it a *meaningful* alias.

You are still not sure that aliases are important? Check the [[Plugins]] page, and how **Dataview** works!

