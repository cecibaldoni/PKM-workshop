---
title: Foraging Strategies
aliases:
  - Types of Foraging
  - Foraging Types
status: literature
tags:
  - "#literature"
  - biology
  - foraging
---
This note might store literature information needed for [[Project One]]

For example:



Foraging can be categorized in two groups: Solitary Foraging or Group Foraging.

### Solitary Foraging

When an animal look for, find, get and consume their prey alone. 

### Group Foraging

Animals look for, find, get and consume preys with other individuals.