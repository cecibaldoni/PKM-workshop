---
title: Project One
tags:
  - decision_making
  - foraging
aliases:
  - Decision-Making and Foraging
status: ongoing
---
## Project One: Animal Behavior and Decision-Making

This is an example project of a PhD in #biology or #behavioral_ecology. The topic could be exploring, for example, how animals make foraging decisions. 
Notes are tagged with `#foraging` and `#decision_making` to group related content. But notes could be sparse in the text as well, if they are related to bigger topics.

Use these tags to locate notes or explore the relationships in the graph view!
## Example Key Topics 
[[Foraging Strategies]]
[[Risk and Reward in Foraging]]  
## Notes 
[[Methodology]]
[[Preliminary Results]] 
## Links 

This project relates to [[Behavioral Ecology Concepts]].