---
title: Project Two
aliases:
  - Invasive Plants and Animals
  - Invasive Animals and Plants
tags:
  - alien
  - biology
  - invasive
status: ongoing
---
## Project Two: Invasive Animals and Plants

This is an example project of a PhD in #biology .
The topic could be exploring, for example, what makes an #alien or an #invasive species successful. 
The tags help you group related content. Notes can be in the `metadata` or scattered in the text, if they are related to bigger topics.

Use these tags to locate notes or explore the relationships in the graph view!
## Example Key Topics 
[[Invasive Parakeet in Europe]]
## Links 

This project also relates to [[Behavioral Ecology Concepts]] (check the graph view: see how Project One and Two are connected by this common note? )