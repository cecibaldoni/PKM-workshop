Meeting Notes: Discussed progress on Study 2. Supervisor said the introduction is “too vague” and we need to expand X methods. Mentioned the guy who worked on that thing in 2020 (need to find the paper). Also mentioned Gray 2019 but didn’t clarify its relevance. Figure 4 still needs fixing—double-check the data and formatting. Action items: Write draft results for Study 2 and send by Monday; Email Dr. Gray about statistical methods by Friday; Prepare questions about methodology; Summarize findings for lab meeting; Explore collaboration with Dr. Gray on the methodology section.

Could the new statistical method improve the accuracy of our findings? Need to test this. Dr. Gray might have insights on applying X methodology. Should we explore an additional control group for Study 2? Check if the current design is sufficient. Does Figure 4 follow journal guidelines? Double-check formatting!

Prepare a summary of Study 2 progress for the lab meeting on Thursday. Include: Updated Figure 4, a quick evaluation of statistical methods, and Gray 2019’s potential relevance. Should also ask for feedback on the new control group idea.

Literature to review: Guy who worked on that thing in 2020 (who was it again?); Gray 2019; Smith 2020 (is this relevant?). Make a priority list for reading this week.

To-Do: Fix Figure 4; Summarize results and send to supervisor; Draft an email about statistical methods to Dr. Gray; Prepare for the lab meeting; Review literature (Gray 2019, Smith 2020, and “that guy”). Write an email to the journal editor to clarify submission guidelines.

Random ideas: Should we use Smith 2020’s critique in the discussion section? Is Gray 2019 worth citing if it overlaps with other methods? Could adding a control group make our argument stronger? If the graph format in Figure 4 is wrong, will the journal desk reject it outright? Are we missing critical background references for Study 2?


