**Ring-necked and monk parakeets** are by far the most common parakeet invaders in Europe. [Source](https://www.kent.ac.uk/parrotnet/policybrief/policies/ParrotNet_English.pdf)

![[RingNecked_juvie.jpg]]
This is how the Ring-Necked Parakeet (*Psittacula krameri*) looks like as a juvenile individual.

![[monkparakeet.jpeg]]
And this is a Monk Parakeet (*Myiopsitta monachus*)!