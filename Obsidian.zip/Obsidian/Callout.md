Callouts in Obsidian are those special blocks that visually highlight information in your notes. They’re perfect for emphasizing important points, creating checklists, or adding warnings and tips. 

Callouts are styled blocks with a header and optional content, making your notes more organized and sooo visually appealing.

## How to Create Callouts

A callout block begins with `[!Type]`, where `Type` is the kind of callout (e.g., `note`, `tip`, `warning`). Then, add the content of your callout directly below the header:

```
> [!tip] This is the header for the callout. 
> This is the additional content within the callout.
```

Here are some pre-made examples:
## Examples

>[!example]  
This is how callouts work in Obsidian.

>[!note]  
 This is a note callout.

>[!todo]
>Remember your to-do list!

>[!tip]  
Here’s a useful tip!

> [!tip] Can also be title-only!

> [!summary]  
Summarize a concept in a callout!

> [!success]  
You’ve successfully completed this section!

> [!help]
> Is this section clear?

> [!warning]  
Be careful! 

> [!question]- Did you know that...?
> > [!tip]- Callout are foldable, and....
> > > [!example]  Callouts can be nested!

>[!danger]  
This action cannot be undone!

>[!bug]  
Bug to fix!

>[!quote]  
"Someone famous said this once"
