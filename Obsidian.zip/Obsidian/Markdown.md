>[!quote]  
>Markdown is a lightweight markup language that you can use to add formatting elements to plaintext text documents.

During the workshop, we learned to use markdown with this [Collaborative Pad](https://pad.gwdg.de/s/5EEnJQuae)

You can find a lot of cheatsheets online, here are a few:

[Official Markdown Cheat Sheet](https://www.markdownguide.org/cheat-sheet/)
[Cheatsheet with Advanced Featured](https://github.com/lifeparticle/Markdown-Cheatsheet)
[A Cheatsheet PDF](https://opensource.com/sites/default/files/gated-content/markdown_cheat_sheet_opensource.com_.pdf)