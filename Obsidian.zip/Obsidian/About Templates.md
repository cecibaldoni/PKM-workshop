Templates make it easy to quickly create structured notes for common tasks. This vault includes templates for the following:

- **Meetings**: Capture key points, attendees, and action items.
- **Freewriting Sessions**: A blank template for brainstorming or writing freely.
- **Weekly Reviews**: Reflect on the past week and plan the next one.
- **Paper Summaries**: Summarize key points from research papers.

## How to Use Templates

The **Templates plugin** is already enabled in this vault, so you can insert a template into any note with just a few clicks. Here’s how it works:

1. **Create a New Note**: Use the `New Note` button in the sidebar or press `Ctrl/Cmd+N` to create a blank note.
2. **Insert a Template**:
    - Open the **Command Palette** (Ctrl/Cmd+P).
    - Search for "Insert Template" and select it.
    - A list of available templates will appear. Choose the one you want to use.
3. **Edit and Customize**: Once the template is inserted, you can modify it to fit your specific needs. For example, you can adjust the date in a meeting note or add new sections to a paper summary.

## Where Are Templates Stored?

The templates are located in the **Templates folder** in this vault. If you’d like to create your own templates or edit the existing ones, simply navigate to this folder, open the template file, and make your changes.