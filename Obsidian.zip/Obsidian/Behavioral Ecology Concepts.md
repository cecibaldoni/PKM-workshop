---
title: Behavioural Ecology Concepts
aliases:
  - Behavioural Ecology
tags:
  - biology
  - literature
  - behavioral_ecology
---
Collection of notes on Behavioural Ecology Concepts, related to both [[Project One]] and [[Project Two]]

**Optimal Foraging Theory**: This theory says that animals forage in a way that maximizes their net energy intake per unit of time, balancing the energy gained from food with the energy expended to obtain it.
e.g. papers: [Davis et al., 2022](https://www.cell.com/trends/ecology-evolution/fulltext/S0169-5347(22)00143-4)

See also the note on [[Foraging Strategies|Foraging Types]]

**Game Theory** in #animal_behavior: The application of mathematical models to understand strategic interactions between individuals, predicting behaviors that maximize fitness in competitive situations.

**Sexual Selection**: A mode of natural selection where certain traits increase an individual's chances of mating and reproducing, often leading to pronounced differences between sexes.