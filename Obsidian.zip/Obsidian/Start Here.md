Welcome to your new [[Obsidian]] vault! 🎉

It’s packed with features to help you organize your ideas, connect concepts, and draft like a pro. This vault is designed as a playground for [[PhD]] students to experiment with [[Obsidian]] while learning how it can support your research and writing.

If you’re completely new to [[Obsidian]], don’t worry: this [[vault]] is made for you! 

>[!tip]  
For a deeper dive into its features and capabilities, check out the [official Obsidian documentation](https://help.obsidian.md/Home) or the [Obsidian Community](https://forum.obsidian.md/), where you can find tips, tricks, and plugins created by other users.

What did I just do here? Check the [[Callout]] page!
## Overview of Vault Structure

In Obsidian, a "vault" is simply a folder on your computer where all your notes live. Each note is a Markdown file that can be linked to others, creating a network of ideas. This vault is set up to give you an idea of how you can structure and navigate your own work.

To get around, the **Command Palette** (Ctrl/Cmd+P) is your new best friend.
For quickly hopping between notes, use the **Quick Switcher** (Ctrl/Cmd+O), which makes navigating large vaults a lot easier. 

I’ve prepared a few areas in this vault to get you started. Let’s take a tour of what you’ll find:
### Templates

Templates are pre-prepared structures designed to make repetitive tasks quicker and easier. 
In this vault, I created some templates for meetings ([[Meeting Template]]), [[Freewriting]] sessions, [[Weekly Review]], and paper summaries. You will find them inside the folder "Templates".
They can be used as-is, or customized to fit your workflow. 

Check the [[About Templates]] for instructions on how to insert a template into a note.

### Research Projects

This section is an example of how to organize a Research Project. It’s based on my own [[PhD]] work, with a breakdown into projects or subtopics (go have a look at [[Project One]]). You can rearrange it however you want, for example by Chapters.
You’ll see how notes for each section link back to a central project page, making it easy to keep everything connected. This structure can be adapted for your own research topics, or you can change it completely based on what is your preferred organisational method!
### Tags

Tags in [[Obsidian]] are just ways to organize and group your notes. You can categorize your note based on topics, status, or other criteria you find useful. Most importantly, they are great to find related notes across your [[vault]] when you don't want to rely on the folder structure.

To learn more, have a look at the [[Tags]] note!

