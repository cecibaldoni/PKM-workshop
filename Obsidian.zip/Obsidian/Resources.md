Here I grouped a bunch of Resources I found useful when I first started using [[Obsidian]].

[Obsidian for Academics](https://publish.obsidian.md/hub/04+-+Guides%2C+Workflows%2C+%26+Courses/for+Academic+Writing): comprehensive list of resources (articles, videos) on how to use Obsidian for Academics from the Obsidian Hub.
[How to make note and write, by Dan Allosso](https://docdrop.org/pdf/How-to-Make-Notes-and-Write---Allosso-Dan-jzdq8.pdf/): Nice handbook on note-taking and PKM, free to download.

#### Vault Examples
This is a list of ready-to-use vaults from other community members. 

[Obsidian Scientific Research Vault](https://github.com/LalieA/obsidian-scientific-research-vault)by [LalieA](https://github.com/LalieA/obsidian-scientific-research-vault/commits?author=LalieA): this vault might be useful to see different organization approaches.
[Obsidian for Academia](https://github.com/rlaker/Obsidian-for-Academia) by [rlaker](https://github.com/rlaker/Obsidian-for-Academia/commits?author=rlaker): this vault has a nice git and Zotero integration.
[Obsidian Electronic Lab Notebook](https://github.com/fcskit/obsidian-eln): Vault for collecting and organizing research data, I personally did not try it yet so I can't vouch for its efficiency, but I will update soon.