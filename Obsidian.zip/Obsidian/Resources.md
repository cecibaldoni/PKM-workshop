Here I grouped a bunch of Resources I found useful when I first started using [[Obsidian]].

[Obsidian for Academics](https://publish.obsidian.md/hub/04+-+Guides%2C+Workflows%2C+%26+Courses/for+Academic+Writing)
