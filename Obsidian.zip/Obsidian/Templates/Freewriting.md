### Freewriting Session: {{date}}

Write the main topic, question, or idea you want to explore.
#### Option 1: Unfiltered Writing 
*Write freely for 10–15 minutes.* 
*Don’t worry about structure, grammar, or logic.*

#### Option 2: Structured Pomodoro Session
1. Set a timer for 25 or 50 minutes. 
2. Write with focus on your chosen task/topic until the timer ends. 
3. After a 25 minutes work session, take a 5-minute break, or a 10 minutes break after 50 minutes work,then repeat. 
4. After 2 hours, take a longer break (15–20 minutes).

#### What Next? 
*Write down an idea, question, or task you want to follow up on*