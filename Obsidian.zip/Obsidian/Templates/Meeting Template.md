# Meeting Notes:  {{date}} 

**Date:** {{date}} 
**Time:** {{time}}
**Location**:
**Topic**:

--- 
## Agenda 

1. 
2. 
3. 

--- 
## Topics 

- First point
- Second point

--- 
## Actions 

- [ ] This is a todo point
- [ ] And another one

---

## Notes for Follow-Up 

- 