### "More Journal Templates" plugin >
comment:: [English document](https://github.com/YU000jp/logseq-plugin-weekdays-and-weekends/wiki/English-document)
	- #### Journal-template config >
	  template:: Journal
	  template-including-parent:: false
	  comment:: Replace `:default-templates {:journals "Journal"}` in the "config.edn" file. Rendering occurs when it is loaded as a journal template.
	  background-color:: yellow
		- {{renderer :Weekdays, Mondays, Mon}}
		  {{renderer :Weekdays, Tuesdays, Tue}}
		  {{renderer :Weekdays, Wednesdays, Wed}}
		  {{renderer :Weekdays, Thursdays, Thu}}
		  {{renderer :Weekdays, Fridays, Fri}}
		  {{renderer :Weekdays, Saturdays, Sat}}
		  {{renderer :Weekdays, Sundays, Sun}}
	- background-color:: gray
	  template:: Mondays
	  template-including-parent:: false
		- *Morgen*
			-
		- *Nachmittag*
			-
		- *Abend*
			-
	- background-color:: gray
	  template:: Tuesdays
	  template-including-parent:: false
		- *Morgen*
			- 10:30 Seminar
		- *Nachmittag*
			-
		- *Abend*
			-
	- template::  Wednesdays
	  template-including-parent:: false
		- *Morgen*
			-
		- *Nachmittag*
			-
		- *Abend*
	- template::  Thursday
	  template-including-parent:: false
		- *Morgen*
			-
		- *Nachmittag*
			- 15:00 Lab Meeting
		- *Abend*
			-
	- background-color:: gray
	  template:: Fridays
	  template-including-parent:: false
		- *Morgen*
			- 10:30  Rado Seminar
		- *Nachmittag*
			-
		- *Abend*
			-
	- #### Weekends-Template:
	  background-color:: gray
	  template:: Saturdays
	  template-including-parent:: false
		- ### Weekends
			- *Morgen*
				-
			- *Nachmittag*
	- #### Weekends-Template:
	  background-color:: gray
	  template:: Sundays
	  template-including-parent:: false
		- ### Weekends
			- *Morgen*
				-
			- *Nachmittag*
				-