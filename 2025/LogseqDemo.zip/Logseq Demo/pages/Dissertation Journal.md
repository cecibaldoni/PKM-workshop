tags:: writing , PhD , Dissertation

- ## What is it?
	- Journal to keep track of **reflections**, **questions**, **topics** or **feelings** about dissertation, phd and writing process.
- **List of PRO**:
	- bring out of writer's block, practice writing without revising
	- *does not* substitute actual writing: it is not meant to keep paragraphs for the next paper.
	- help keep track of how much work *can realistically* be done in a day
	- help get in the writing mood, probably best done in the morning before the day starts
- ### List of Prompts:
	- Where am I at? What did I accomplish today?
	- What was my biggest obstacle? What do I do in the future if I find this again?
	- Is there anything I need to read or learn before the next writing session?
	- How should I start the next session of this project?
- ### Resources
	- [The dissertation Journal that saved my sanity](https://cecibaldoni.github.io/blog/dissertation-journal.html) by [[Cecilia Baldoni]]
	- [Keeping a dissertation journal](https://thetendingyear.com/1-38-keeping-a-dissertation-journal/) by Kate Henry