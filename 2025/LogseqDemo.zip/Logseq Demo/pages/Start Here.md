## Welcome to your new #Logseq graph! 🥳
	- This is your starting point for exploring how **Logseq** can help you organize your work or research, connect ideas, and manage tasks. This graph is designed as a sandbox for  [[PhD]] students, researchers, or [[research support]] to experiment with #Logseq and discovering its potential.
	- If you’re completely new to **Logseq**, don’t worry: this #graph is built with you in mind!
	- #+BEGIN_TIP
	  For detailed guidance, check out the [official Logseq documentation](https://docs.logseq.com/#/page/contents) or join the [Logseq Forum](https://discuss.logseq.com/) for tips, ideas, and inspiration from other users.
	  #+END_TIP
	- What did I just do here? Check out the [[Block types]] page to learn more!
- ## Overview of Graph Structure
  In Logseq, a `graph` is your knowledge base, consisting of interconnected notes and blocks. It’s stored as plain `Markdown` files on your computer, ensuring full privacy and offline access.
	- ### Getting Around
		- Logseq’s **Command Palette** `Ctrl/Cmd+K` is your new best friend for shortcuts and quick actions.
		- Check out the `Build in commands` in Logseq, just by typing `/`
		- Want to see connections between your notes?
			- Open the **Graph View** to visualize your network of ideas. It’s a great way to discover relationships and patterns in your research.
- ## What's in This Graph?
	- I’ve set up a few areas to help you get started:
	- ### Research Projects
		- This section provides an example of how to organize a project using Logseq. It’s based on #Ceci PhD work and showcases a breakdown of a central project into subtopics ([click here]([[Project1]])   for an example). You can rearrange it by:
			- **PhD Chapters**
			- **Themes**
			- **People** or **Projects**
		- Each section links back to the main project page, showing how you can create a web of related notes. Use this as inspiration for structuring your own work or adapt it to suit your unique needs!
	- ### Page Properties
		- In Logseq, page properties are key-value pairs defined in the first block of a page to add ((691edc59-0404-43a4-965c-6aea05654215)) ⬅️ click here to know more!
		  id:: 691edc5a-c1c4-48d1-8033-1a5b95aa03e3
	- ### Templates
		- In this graph I installed the plugin called: [logseq-plugin-weekdays-and-holidays](https://github.com/YU000jp/logseq-plugin-weekdays-and-weekends) with pre-defined templates for each day of the week, completely customizable!
		- This plugin allows you to set unique templates for each day of the week, making your daily notes even more personalized and dynamic.
		- For example:
			- Do you have a recurring meeting on **Tuesday**? You don't have to put it every week, but just in the template!
			- **Mondays** might focus on task planning and setting priorities.
			- **Fridays** could include a "Weekly Review" section.
	- ### Plugins
		- In this graph I installed three plugins:
			- [logseq-plugin-weekdays-and-holidays](https://github.com/YU000jp/logseq-plugin-weekdays-and-weekends), described below
			- [Journals Calendar](https://github.com/xyhp915/logseq-journals-calendar)
			- [Emoji Picker](https://github.com/walsvid/logseq-emoji-picker-fork)
		- You can see at more interesting [[Plugins]] ⬅️ here, or by clicking the puzzle piece on the top right corner, and then "Plugins" and then check "Marketplace"
-