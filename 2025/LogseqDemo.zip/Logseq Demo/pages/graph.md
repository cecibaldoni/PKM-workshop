- Fancy name for folder in #Logseq
- in #Obsidian we would call it `vault`!
-
- What is a graph? #card
  card-last-interval:: 4
  card-repeats:: 1
  card-ease-factor:: 2.6
  card-next-schedule:: 2025-11-24T09:17:49.990Z
  card-last-reviewed:: 2025-11-20T09:17:49.992Z
  card-last-score:: 5
  collapsed:: true
	- Fancy name for folder in #Logseq