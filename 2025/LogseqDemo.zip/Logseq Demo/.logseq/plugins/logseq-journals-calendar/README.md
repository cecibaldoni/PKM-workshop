## Logseq journals calendar

A simple journals calendar plugin for Logseq.

### Demo

![demo](./demo.gif)

### Licence

MIT
