tags:: #statistics #RStudio #git #Python

- | Main | Topic | Link | 
  | --------- | ---- | ---- |
  |STAT |1. tidyverse | [R4DataScience](https://r4ds.had.co.nz/introduction.html) | 
  |        | 2a. Statistical inference via Data Science `moderndive` | [moderndive](https://moderndive.com/index.html) | 
  ||2b.stat learning in R | [An Introduction to Statistical Learning with Applications in R](https://hastie.su.domains/ISLR2/ISLRv2_website.pdf)|
  |        | 3. Beyond Multiple LR |[BMLR](https://bookdown.org/roback/bookdown-BeyondMLR/)|
  | | 4a. Bayesian Stats| [The Fun Way](https://learning.oreilly.com/library/view/bayesian-statistics-the/9781098122492/xhtml/ch06.xhtml#ch06lev1sec1) | 
  | | 4b. Tidy Modeling with R | [tidymodel](https://www.tmwr.org/) [learn tidymodels](https://www.tidymodels.org/)| 
  || 4c. Learn Tidymodels | [Learn](https://www.tidymodels.org/learn/) | 
  || Linear Algebra| [Strand Algebra](https://www.youtube.com/playlist?list=PL49CF3715CB9EF31D)| 
  ||Statistical Rethinking| [mcelreath](https://www.youtube.com/playlist?list=PLDcUM9US4XdMROZ57-OIRtIK0aOynbgZN) | 
  || rethinking {brms} | [brms](https://bookdown.org/content/4857/) |
  ||Bayesian Workflow| [BayesianWorkflow](https://arxiv.org/pdf/2011.01808.pdf)||
  |STAT PYTHON| Think Bayes| [ThinkBayes](https://allendowney.github.io/ThinkBayes2/)| 
  ||Data exploration and wrangling(pandas)| [PythonofAI 2](https://www.youtube.com/watch?v=aLphsae3PSE&t=978s)|
  |ANIMOVE|MovementAnalysis|[animove](https://animove.org/elearning/)|
  ||Data management, Segmentation, resource selection|[animove](https://animove.org/elearning/)|
  || CTMM| [animove](https://animove.org/elearning/)|
  |Movement| plots | [Making Maps with R](https://bookdown.org/nicohahn/making_maps_with_r5/docs/introduction.html)| 
  || recurse | [`recurse`](https://cran.r-project.org/web/packages/recurse/vignettes/recurse.html) |
  |git| Git&Github | [HappyGit](https://happygitwithr.com/index.html) |
  || Python Data Science | [Python Data Science Handbook](https://jakevdp.github.io/PythonDataScienceHandbook/)| 
  |R| shiny | [shiny](https://shiny.rstudio.com/tutorial/) |
  || Quarto | [quarto](https://quarto.org/docs/get-started/hello/rstudio.html)|
  |other| matlab | [mathworks](https://matlab.mathworks.com/) |
  |  | Data Wrangling | [Data Wrangling Part 1](https://suzan.rbind.io/2018/01/dplyr-tutorial-1/)|
-