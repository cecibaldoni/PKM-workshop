title:: statistics

- ## Theory
	- ### Linear regression
		- The general form of a linear model with one input feature is: `y = mx + b`
			- `y` is the predicted output variable (dependent variable)
			- `x` is the input variable (independent variable)
			- `m` is the slope or coefficient. representing the change in y for a unit in change in x
			- `b` is the y-intercept, representing the value of y when x is 0
		- The process of fitting involves finding the best values of the intercept b0 that minimize the difference between predicted values and the actual values (best fitting line to our data). This is typically achieved using optimization techniques like *ordinary least squares* (OLS).
			- OLS: after we calculate the predicted values, we can calculate the difference between observed and predicted values, called *residuals*. the goal is to  values of b that minimize the sum of squared residuals (SSR) over all data points.
		- Once we obtain the optimal coefficients (m and b), they represent the y-intercept and slope of the best-fitting line through the data points. The line with these coefficients is the one that minimizes the sum of squared residuals and provides the best linear fit to the data
		-
	- ### Linear Mixed Models
		- linear mixed models extend the linear model with a *random effect*
	- The `binomial` family is used when the response variable is binary, representing the number of successes in a fixed number of trials (e.g., the number of heads in 10 ). The `bernoulli` family is a special case of the `binomial` family, where there is only one trial (i.e., a single success or failure).
	- ### Data Modeling
		- serves one of two purposes:
			- Modeling for **explanation**: to describe relationship between outcome *y* and variables *x* (Supervised models)
			  Modeling for **prediction**: to predict an outcome *y* based on the information contained in a set of variables *x*. in this case I don't care much how all the variable are related and interact with each other. (Unsupervised models)
		- ### Basic regression
			- Relationship between *x* and *y* is assumed to be linear.
			- `skim()` for df returns **UNIVARIATE** summary statistics, cioè it takes one variable x and returns a numerical summary of that variable
			- **BIVARIATE** summary statistics, cioè it takes 2 variables and returns the summary of those. If the variables are *numerical*, i can get a **correlation coefficient**, that tells me the strength of linear relationship between two numerical variables
			  -1 negative relationship, 0 no relationship, +1 positive relationship
			  `df >%> get_correlation(formula = y~x)` (package Moderndive)
			  `df >%> summarize(correlation= cor(y, x))`