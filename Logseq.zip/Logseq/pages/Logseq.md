- **Logseq** is a local, open-source note-taking and knowledge management tool designed to help you organize and connect your thoughts.
  id:: 67460378-cb29-4091-89e6-25db2c522710
- ## How Are Notes Organized in Logseq?
	- Logseq is based on an **outliner structure**, where every piece of information is a block that can be nested, expanded, or referenced dynamically.
		- This means that, at its core, all information is stored as bullet points.
	- **Blocks** function as individual pieces of content. Each block can stand alone, be linked to other blocks or pages or form a hierarchy.
	- For example, a note can start with a main idea: (*click on the bullet point of this line!*)
	  collapsed:: true
		- and underneath you can add nested points
			- or nested tasks or subtopics
	- Logseq is **folder-agnostic**. Instead of relying on rigid folder structures to organize notes, it promotes a **web-like organization** using links, tags, and hierarchies. This means your notes are connected by relationships rather than location, making it easier to retrieve and use information without remembering where you stored it.
- ## What Makes Logseq Unique?
	- **Daily Journaling**:
		- Logseq automatically creates a daily page where you can write tasks, thoughts, or anything else.
		- These daily notes are an excellent entry point for capturing ideas quickly.
	- **Task Management**:
		- Logseq integrates tasks directly into your notes using markers like `TODO`, `DOING`, or `DONE`. For more, see the [[Block types]] page!
		- You can create **task queries** to filter and manage tasks across pages.
	- **Block and Page References**:
		- References allow you to link back to specific blocks or entire pages, creating connections across your notes and avoiding repetition.
	- **Block and Page Embeds**:
		- Embeds let you display the content of a block or an entire page within another note, preserving its original structure.
	- **Metadata**:
		- Logseq uses **Page Properties** to define metadata. This is like #Obsidian ’s YAML frontmatter but is written directly in your notes.
		- Example of Metadata in Logseq:
			- ``` markdown
			  title:: Research Notes
			  tags:: #biology #analyses
			  priority:: /A
			  status:: ongoing
			  ```
		- You can add metadata to the top of any page or block to structure your notes and enhance searchability.
- ## How Do Queries Work in Logseq?
	- One of Logseq's most powerful features is its ability to create **custom queries**. Queries allow you to filter your notes dynamically based on criteria like tags, task status, or page properties.
	- Example Query to Find All `TODO` Tasks:
	- ``` markdown
	  {{query (task TODO)}}
	  ```
	- Or:
	- ``` markdown
	  {{query (and (task TODO) [[#Project1]])}}
	  ```
	- Check out the Official Documentation on [Queries](https://docs.logseq.com/#/page/queries)