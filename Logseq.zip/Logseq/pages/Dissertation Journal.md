status:: ongoing 
tags:: writing , PhD , Dissertation

- ## What is it?
	- Journal to keep track of **reflections**, **questions**, **topics** or **feelings** about dissertation, phd and writing process.
- **List of PRO**:
	- bring out of writer's block, practice writing without revising
	- *does not* substitute actual writing: it is not meant to keep paragraphs for my next paper.
	- help keep track of how much work *can realistically* be done in a day
	- help get in the writing mood, probably best done in the morning before the day starts
- ==To think about:== Is the pre writing session done in the morning before the day starts? Or just before the writing? I guess before the writing, but then I need to rethink the 20 minutes morning time.
  Probably I just have to try to use it at pre writing time and see if it works. Also because writing times at the beginning are not likely to be everyday, while the journal is.
- Check out `writing yoga`, the secret is just *keep writing*. No phone for inspiration, no glazing over the window (except for thinking). And write about your dissertation, not what you cooked yesterday.
- ## POST Writing Session
	- 20 minutes, summary of what happened in this writing session.
	- The point is both to see how much I've accomplished, but also to have a starting point for the next day, where I can start from.
- ### List of Prompts:
	- Where am I at? What did I accomplish today?
	- What was my biggest obstacle? What do I do in the future if I find this again?
	- Is there anything I need to read or learn before the next writing session?
	- How should I start the next session of this project?