- Logseq supports various block types to organize and format your content effectively.
	- These block types come from **Org Mode syntax** and can be styled or structured for specific use cases, making your notes more dynamic and visually appealing.
- # Org Mode syntax
	- **Org Mode** is a powerful plain text system originally developed for Emacs, a popular text editor among programmers and researchers. It is designed to help users organize your tasks, notes and Projects.
	- #Logseq partially adopts **Org Mode syntax** to enable advanced features like structured blocks, task management, and embedded code.
	- ## Encapsulate content
		- This are similar to #Obsidian 's callouts!
			- #+BEGIN_TIP
			  This is a tip!
			  #+END_TIP
			- #+BEGIN_NOTE
			  Note to self, drink more water!
			  #+END_NOTE
			- #+BEGIN_IMPORTANT
			  Remember this, it's important!
			  #+END_IMPORTANT
			- #+BEGIN_QUOTE
			  "Someone important said this once."
			  #+END_QUOTE
			- #+BEGIN_PINNED
			  I need to pin this note, because otherwise I'll forget
			  #+END_PINNED
			- #+BEGIN_CAUTION
			  Run this code with caution!
			  #+END_CAUTION
			- #+BEGIN_SRC python
			  print("Hello, world!")	
			  #+END_SRC
			- Spoiler alert! This is a {{cloze hidden word}}
	- ## Tasks
		- Logseq is very powerful in keeping track of your tasks, with some nice built in functions:
		- TODO This is something I need to do
		- DOING This is something I'm doing
		  :LOGBOOK:
		  CLOCK: [2024-11-28 Thu 09:45:26]
		  CLOCK: [2024-11-28 Thu 09:45:27]
		  :END:
		- DONE This task is done!
		- LATER I might need to review this later
		- NOW Very important, working on it NOW!
		  :LOGBOOK:
		  CLOCK: [2024-11-28 Thu 09:46:51]
		  CLOCK: [2024-11-28 Thu 09:46:59]
		  :END:
		- WAITING I can't work on it further, I need my collaborator to send some code
		- CANCELED This task is not done but has been Canceled, or Cancelled (both work!)
		- I need to finish this by the end of the year.
		  DEADLINE: <2024-12-31 Tue>
		- I have a meeting on this date:
		  SCHEDULED: <2024-12-09 Mon>
	- ## Block and Page References:
		- You might want to reference a block where you have already stored some information, just because you don't want to repeat it. Like [this](((674601b0-3581-4e7f-a734-2bbab25b440a)))
		- Page references help you find connections you might not have noticed.
	- ## Block and Page Embeds:
		- While a block reference works on a signle bloc, a block embeds works on all its child blocks.
			- You can embed a block by typing `/block embed`
			- Like this: {{embed ((6746039b-1fe0-424b-a2ac-c2c0a6bbb8eb))}}
		- You can even embed a whole page, try it by typing `/page embed`
	- Logseq organizes notes using an **outliner-based structure**.
id:: 6746039b-1fe0-424b-a2ac-c2c0a6bbb8eb
		- This means all information is stored as bullet points, which can be nested or expanded for clarity.
		- Instead of relying solely on folders, Logseq promotes a **web-like organization** through:
			- `[[links]]` to connect pages and concepts.
			- `#tags` to group and classify information.