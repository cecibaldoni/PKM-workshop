tags:: #writing, #statistics
status:: #ongoing

- ## List of Projects
	- #Project1 - Animal Behavior and Decision-Making
	- #Project2 - Predator-Prey interactions
- ## Dissertation
	- [[Dissertation]]
- ## Tools
	- ### Visualisation
		- [BioRender](http://biorender.com)
		- [BioIcons](https://bioicons.com/)
		- [ColorOracle](https://colororacle.org)
		- [Diagrams](https://app.diagrams.net/)
	- ### Literature
		- [ResearchRabbit](https://www.researchrabbit.ai/)
		- [Papers with Code](https://paperswithcode.com/)
		- [Elicit](https://elicit.org/)
		- [Scite](https://scite.ai/)
	- ### Note-taking
		- [Zettlr](https://www.zettlr.com/)
		- [Scrivener](https://www.literatureandlatte.com/scrivener/)
		-