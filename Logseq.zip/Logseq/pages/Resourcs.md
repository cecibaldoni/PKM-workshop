## PKM Strategies
	- [7 Effective Strategies for Organising your Notes in Your PKM](https://www.thedilettantelife.com/organising-notes-pkm/)
	- [Note Writing System](https://notes.andymatuschak.org/zEZi3ytBhZHHweRYNAosQ1g)