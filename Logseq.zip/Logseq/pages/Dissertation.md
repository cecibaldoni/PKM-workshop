deadline::
status:: 
tag:: #writing #PhD

- ### Structure
	- General Introduction
	- Chapter 1: it will be about #Project2
	- Chapter 2: #Project1
	- TBD with supervisor
	- General Discussion
	- Bibliography