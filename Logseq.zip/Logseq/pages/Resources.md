## Logseq
	- [Getting Started with Advanced Queries](https://hub.logseq.com/features/av5LyiLi5xS7EFQXy4h4K8/getting-started-with-advanced-queries/8xwSRJNVKFJhGSvJUxs5B2)
	- [Logseq Youtube Channel](https://www.youtube.com/c/Logseq)
	- [Logseq for Research](https://blog.logseq.com/newsletter-10-how-to-use-logseq-for-research/)
- ### Templates
	- [Sample Templates](https://logseqtemplates.com/)
- ### Plugins
	- [Logseq Plugin Samples](https://github.com/logseq/logseq-plugin-samples)
- ### Markdown
	- [Markdown CheatSheet](https://www.markdownguide.org/cheat-sheet/)