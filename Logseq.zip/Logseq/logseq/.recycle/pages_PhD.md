tags:: #writing, #statistics
status:: #ongoing

- ## List of Projects
	- #Project1 -
	- #Project2
- ## Dissertation
- ## Tools
	- http://biorender.com: to create figures
	- https://colororacle.org