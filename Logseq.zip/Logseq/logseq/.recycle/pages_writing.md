tags:: #PhD, #writing
title:: WritingTips

- ## List of resources
	- ![Belleville_WRITE YOUR DISSERTATION.011.pdf](../assets/Belleville_WRITE_YOUR_DISSERTATION.011_1732196766139_0.pdf) Belleville - Write your Dissertation
- ## How to write a paper
	- ^^Paragraph^^
		- 2 approaches to build a paragraph:
			- *Top-Down*: first you say the main idea, then you explain it better
			- *Bottom-up*: better used in the discussion, first you say what you have done and be very specific and you draw the conclusions in the end
	- ^^Titles^^
		- *Accurate*, *Brief*, *Clear*, *Declarative*, *Engaging*, *Focused*
	- ^^Abstract/Summary^^
		- 1. Identify the major objectives and conclusions.
		  2. Identify phrases with keywords in the methods section.
		  3. Identify the major results from the discussion or results section.
		  4. Assemble the above information into a single paragraph.
		  5. State your hypothesis or method used in the first sentence.
		  6. Omit background information, literature review, and detailed description of
		  methods.
		  7. Remove extra words and phrases.
		  8. Revise the paragraph so that the summary conveys only the essential
		  information.
		  9. Check to see if it meets the guidelines of the targeted journal.
		  10. Give the summary to a colleague (preferably one who is not familiar with your work) and
		  ask him/her whether it makes sense.