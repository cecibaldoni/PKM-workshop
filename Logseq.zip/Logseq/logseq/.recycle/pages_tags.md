- Tags are keywords prefixed with the `#` symbol that help you organize and categorize your notes dynamically. They are powerful, lightweight, and seamlessly integrated into Logseq's features.
- However, ***they are different from #Obsidian Tags*** because in [[Logseq]] they automatically create a page for each tag you use.
	- This means that every tag becomes a centralized hub for its related content, allowing you to see all references at a glance.
- If you're new to #Logseq you might wander: what is the difference between a tag and a page?
	- Truth is: the difference does not lie in functionality, because both link to a page in your #graph
	- Both `#tags` and `[[links]]` :
		- links to a page when clicked;
		- show up in the `Linked References` section of the page
- ## Using Tags (or Links)
	- The difference between `#tags` and `[[links]]` only lies in **how you use them**, not in what they do. You can use tags for categorisations and page link for direct content linking.
	- You can add tags in two main ways:
		- **Inline in Blocks**
			- `This is a note about #biology and #evolution.`
		- **In Page Properties**
			- ``` plain text
			  tags::  biology, evolution
			  ```
	- Tags integrate seamlessly with Logseq’s powerful query system, allowing you to retrieve blocks or pages with specific tags:
		- ```
		  {{query (and [[biology]] (task TODO))}}
		  ```
- ## Best Practices:
	- **Keep Meaningful Tags**: choose tags that represent important categories
	- **Be Consistent**: tags are case-sensitive, so decide on a capitalization style early on
	- **Avoid over-tagging**:  too many tags can make them less effective
- ## Example Tags
	- **Topics**
	  #biology ; #evolution ; #behavior ; #plasticity ; #conservation
	- **Categories**
	  #literature ; #methods; #pilot ; #writing ; #reviewing
	- **Status**
	  #ongoing ; #onhold ; #draft
	- **Languages, Resources**
	  #Rstudio ; #Python ; #C++ #Arduino ; #git ; #ChatGPT
	- **Personal**
	  #home ; #gym ; #book ; #drawingideas
	- **Moodlog**
	  #stressed ; #focused ; #unfocused ; ;  #excited